package softuni.exam.models.dto;

public class CitySeedDTO {
    private String cityName;
    private String country;

    CitySeedDTO() {
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
