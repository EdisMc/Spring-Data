package softuni.exam.models.dto;

public class ForecastSeedDTO {

    public ForecastSeedDTO() {
    }
}
