package softuni.exam.models.entity.enums;

public enum Day_of_week {
    FRIDAY, SATURDAY, SUNDAY
}
