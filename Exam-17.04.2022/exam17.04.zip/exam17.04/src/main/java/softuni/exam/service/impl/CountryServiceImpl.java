package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.CountriesSeedDTO;
import softuni.exam.models.entity.Country;
import softuni.exam.repository.CountryRepository;
import softuni.exam.service.CountryService;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class CountryServiceImpl implements CountryService {

    private static final Path countryPath = Path.of("src/main/resources/files/json/countries.json");

    private final CountryRepository countryRepository;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final Validator validator;


    @Autowired
    public CountryServiceImpl(CountryRepository countryRepository) {
        this.countryRepository = countryRepository;
        gson = new Gson();
        modelMapper = new ModelMapper();
        validator = Validation.buildDefaultValidatorFactory().getValidator();
    }


    @Override
    public boolean areImported() {
        return this.countryRepository.count() > 0;
    }

    @Override
    public String readCountriesFromFile() throws IOException {
        return Files.readString(countryPath);
    }

    @Override
    public String importCountries() throws IOException {

        String json = this.readCountriesFromFile();
        CountriesSeedDTO[] countryDTOs = this.gson.fromJson(json, CountriesSeedDTO[].class);

        List<String> result = new ArrayList<>();

        for (CountriesSeedDTO countryDTO : countryDTOs) {
            Set<ConstraintViolation<CountriesSeedDTO>> countryErrors = this.validator.validate(countryDTO);

            if (countryErrors.isEmpty()) {
                Optional<Country> countryOptional = this.countryRepository
                        .existsByCountryName(countryDTO.getCountryName());

                if (countryOptional.isEmpty()) {
                    Country country = this.modelMapper.map(countryDTO, Country.class);
                    this.countryRepository.save(country);
                    result.add(String.format("Successfully imported country %s - %s", country.getCountryName(), country.getCurrency()));

                } else {
                    result.add("Invalid country");
                }
            } else {
                result.add("Invalid country");
            }
        }

        return String.join("\n", result);
    }

    @Override
    public Country findById(long id) {
        return null;
    }

}