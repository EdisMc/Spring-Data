package softuni.exam.models.entity;

import softuni.exam.models.entity.enums.Day_of_week;

import javax.persistence.*;
import java.sql.Time;

@Entity
@Table(name = "forecasts")
public class Forecast extends BaseEntity {
    private Day_of_week day_of_week;
    private Double max_temperature;
    private Double min_temperature;
    private Time sunrise;
    private Time sunset;
    private City city;

    public Forecast() {
    }

    @Enumerated(EnumType.STRING)
    public Day_of_week getDay_of_week() {
        return day_of_week;
    }

    public void setDay_of_week(Day_of_week day_of_week) {
        this.day_of_week = day_of_week;
    }

    @Column(nullable = false)
    public Double getMax_temperature() {
        return max_temperature;
    }

    public void setMax_temperature(Double max_temperature) {
        this.max_temperature = max_temperature;
    }

    @Column(nullable = false)
    public Double getMin_temperature() {
        return min_temperature;
    }

    public void setMin_temperature(Double min_temperature) {
        this.min_temperature = min_temperature;
    }

    @Column(nullable = false)
    public Time getSunrise() {
        return sunrise;
    }

    public void setSunrise(Time sunrise) {
        this.sunrise = sunrise;
    }

    @Column(nullable = false)
    public Time getSunset() {
        return sunset;
    }

    public void setSunset(Time sunset) {
        this.sunset = sunset;
    }

    @ManyToOne(optional = false)
    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

}
