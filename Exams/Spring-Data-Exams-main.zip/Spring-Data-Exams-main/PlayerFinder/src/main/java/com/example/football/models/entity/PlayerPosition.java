package com.example.football.models.entity;

public enum PlayerPosition {
    ATT, MID, DEF
}
