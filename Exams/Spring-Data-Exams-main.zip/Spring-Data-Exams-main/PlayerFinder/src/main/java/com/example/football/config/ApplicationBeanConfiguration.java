package com.example.football.config;

//ToDo Create configurations
public class ApplicationBeanConfiguration {
}
