package exam.repository;


//ToDo:
public interface TownRepository {
}
