package exam.config;
//ToDo
public class ApplicationBeanConfiguration {

}
