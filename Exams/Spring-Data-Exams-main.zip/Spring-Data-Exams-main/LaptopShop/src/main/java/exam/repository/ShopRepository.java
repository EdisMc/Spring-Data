package exam.repository;

//ToDo:
public interface ShopRepository {
}
