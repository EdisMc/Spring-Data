package softuni.exam.models.entity.enums;

public enum Rating {
    GOOD, BAD, UNKNOWN
}
