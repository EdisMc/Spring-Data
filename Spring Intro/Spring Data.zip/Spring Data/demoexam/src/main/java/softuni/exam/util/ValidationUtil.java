package softuni.exam.util;


// ToDo Implement interface 
public interface ValidationUtil {

    <E> boolean isValid(E entity);
}
