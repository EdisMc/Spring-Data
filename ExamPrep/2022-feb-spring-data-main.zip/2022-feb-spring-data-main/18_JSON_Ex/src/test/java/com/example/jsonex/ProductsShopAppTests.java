package com.example.jsonex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsShopAppTests {

    @Test
    void contextLoads() {
    }

}
