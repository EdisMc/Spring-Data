package entities;

public class School {

}
