package exam.repository;

//ToDo:
public interface LaptopRepository {
}
