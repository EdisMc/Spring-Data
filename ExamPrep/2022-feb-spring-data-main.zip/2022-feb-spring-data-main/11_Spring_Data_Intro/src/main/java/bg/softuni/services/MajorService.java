package bg.softuni.services;

public interface MajorService {
    void register();
}
