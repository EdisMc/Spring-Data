package bg.softuni.entities;

public class Student {
}
