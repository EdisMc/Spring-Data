package bg.softuni.services;

import org.springframework.stereotype.Service;

@Service
public class MajorServiceImpl implements MajorService {
    @Override
    public void register() {
    }
}
