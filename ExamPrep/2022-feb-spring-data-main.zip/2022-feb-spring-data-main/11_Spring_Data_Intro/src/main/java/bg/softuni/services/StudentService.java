package bg.softuni.services;

public interface StudentService {
    void register();
}
