package com.example.demo.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
