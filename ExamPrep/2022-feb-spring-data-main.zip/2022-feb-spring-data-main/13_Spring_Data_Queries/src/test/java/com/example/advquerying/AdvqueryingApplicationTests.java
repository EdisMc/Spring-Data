package com.example.advquerying;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvqueryingApplicationTests {

    @Test
    void contextLoads() {
    }

}
