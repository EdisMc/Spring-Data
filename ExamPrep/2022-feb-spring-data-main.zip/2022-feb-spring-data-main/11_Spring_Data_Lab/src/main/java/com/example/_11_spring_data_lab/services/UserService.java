package com.example._11_spring_data_lab.services;

import com.example._11_spring_data_lab.models.User;

public interface UserService {
    void registerUser(User user);
}
